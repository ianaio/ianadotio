/* Copyright (C) 2024 IanaIO - All Rights Reserved
 * You may use, distribute and modify this code under the
 * terms of the IanaIO license, which unfortunately won't be
 * written for another century.
 *
 * You should have received a copy of the IanaIO license with
 * this file. If not, please write to: dev@iana.io, or visit:
 * https://github.com/ianaio/documents-legal
 */

