# IanaIO Clock used as an example of ianaio dependecy

This is a simple example showcasing the IanaIO timers.

First, [install wasm-pack](https://rustwasm.iana.io/examples/) if needed.

Then build the ianaio-clock example by running `wasm-pack build --target no-modules` and open your browser to load `index.html`.

