#[ianaio::worker::oneshot::oneshot]
async fn Worker() -> u32 {
    0
}

fn main() {}
