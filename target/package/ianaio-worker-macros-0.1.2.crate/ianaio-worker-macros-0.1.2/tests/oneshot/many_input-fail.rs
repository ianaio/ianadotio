#[ianaio::worker::oneshot::oneshot]
async fn Worker(input_1: u32, input_2: u32) -> u32 {
    0
}

fn main() {}
